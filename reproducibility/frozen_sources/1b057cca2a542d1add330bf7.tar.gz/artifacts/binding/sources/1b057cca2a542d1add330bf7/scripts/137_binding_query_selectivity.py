#!/usr/bin/env python
"""Fixed queried/unqueried discovery readouts; numerical fits belong in sbatch."""
import argparse
import json
from pathlib import Path

from codecue.binding import query_selectivity as query


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('preflight', 'run', 'audit'))
    parser.add_argument('config')
    args = parser.parse_args()
    result = getattr(query, args.command)(json.loads(Path(args.config).read_text()))
    print(json.dumps({key: result[key] for key in ('status', 'evaluation_role', 'cases',
        'factorizations', 'independent_heads', 'parameter_replay_rows', 'new_model_queries') if key in result}, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
