"""Evidence-linked execution status for the user-authorized ten-experiment program."""
from __future__ import annotations
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path
from .datasets import digest,write_json


def load_verified_decision(path):
    path=Path(path)
    if not path.exists():return None
    decision=json.loads(path.read_text());manifest=json.loads(path.with_name('manifest.json').read_text())
    if (manifest['identity_hash']!=digest(manifest['identity']) or decision['identity_hash']!=manifest['identity_hash']):
        raise ValueError('program diagnostic provenance mismatch')
    response=path.with_name('responses.jsonl')
    if hashlib.sha256(response.read_bytes()).hexdigest()!=decision['responses_sha256']:
        raise ValueError('program diagnostic responses changed')
    dataset=Path(manifest['identity']['config']['dataset'])
    if hashlib.sha256(dataset.read_bytes()).hexdigest()!=manifest['identity']['dataset_manifest']['sha256']:
        raise ValueError('program diagnostic dataset changed')
    return decision


def status(config):
    root=Path(config.get('artifact_root','artifacts/binding/phase2'))
    plan_path=Path(config['plan']);plan=json.loads(plan_path.read_text())
    audit=json.loads((root/'checkpoint_audit.json').read_text()) if (root/'checkpoint_audit.json').exists() else None
    boundary=json.loads((root/'tokenizer_boundary_audit.json').read_text()) if (root/'tokenizer_boundary_audit.json').exists() else None
    paired=json.loads((root/'boundary_validation/comparison.json').read_text()) if (root/'boundary_validation/comparison.json').exists() else None
    audit_ok=(audit is not None and all(r['match'] for r in audit['files']) and boundary is not None and boundary['status']=='passed')
    decisions={name:load_verified_decision(root/name/'protocol_calibration/diagnostic_decision.json')
               for name in ('arithmetic_forms','arithmetic_free')}
    token_path=root/'all_prompt_token_audit.json'
    token_audit=json.loads(token_path.read_text()) if token_path.exists() else None
    token_ok=token_audit is not None and token_audit['status']=='passed' and token_audit['n']==1152
    if token_ok:
        for file,expected in token_audit['input_hashes'].items():
            if hashlib.sha256(Path(file).read_bytes()).hexdigest()!=expected:
                raise ValueError('full reference-token audit is stale')
    candidate=next(({'task':name,'protocol':r['selected_protocol'],'identity_hash':r['identity_hash']}
                for name,r in decisions.items() if r is not None and r['status']=='validated_for_discovery'),None)
    ready=candidate if token_ok and audit_ok else None
    done=all(r is not None and r['complete'] for r in decisions.values())
    stages=[]
    for experiment in plan['experiments']:
        identifier=experiment['id'];entry=dict(experiment)
        if identifier==1:
            entry['status']='completed_with_boundary_correction' if audit_ok and paired else 'audit_incomplete_or_failed'
            entry['interpretation']='Artifact integrity passed; native token boundary disagreed with reference and an explicit correction was verified. Paired behavior measures its limited empirical effect.'
        elif identifier in (2,3):
            key='arithmetic_forms' if identifier==2 else 'arithmetic_free';result=decisions[key]
            entry['status']='completed' if result is not None and result['complete'] else 'pending_or_running'
            entry['decision']=result
        else:
            entry['status']=('waiting_for_reference_token_audit' if candidate and not token_ok else
                             'ready_for_frozen_discovery_design' if ready and identifier==4 else
                             'waiting_for_upstream_experiment' if ready or not done else
                             'not_run_failed_behavioral_prerequisite')
            if done and candidate is None:
                entry['reason']='Neither diagnostic produced a protocol meeting the predeclared training and fresh-validation arithmetic/binding gate.'
            if identifier==9:entry['registration']='No empirical explanatory registration or C features have been invented.'
            if identifier==10:entry['replication_scope']='The user authorized a second family; execution still requires an observed effect and a reserved global allowance.'
        stages.append(entry)
    result=dict(generated_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                experiments=stages,discovery_candidate=ready,diagnostics_complete=done,
                full_reference_token_audit=token_audit,heldout_outcomes_opened=False,
                prior_pilot='Preserved separately; this program follows the user request to execute the proposed experiments.')
    write_json(root/'program_status.json',result)
    text=['# Authorized experiment program','',f"Generated {result['generated_utc']}.", '',
          'The user authorized all ten proposed experiments. Scientific prerequisites determine which model runs are eligible. '
          'The earlier pilot is retained separately. The new checkpoint audit verifies public artifact hashes and discovers a tokenizer boundary discrepancy; '
          'the explicit correction is independently checked against raw SentencePiece. Its effect is measured on paired same-GPU runs.', '',
          '| Experiment | State |', '|---|---|']
    text += [f"| {r['id']}. {r['name']} | `{r['status']}` |" for r in stages]
    text += ['', '## New behavioral diagnostics','',
             'Protocol selection uses only training elementary cells at at least 90% exact accuracy and at most 5% invalid outputs, '
             'with at least 24 examples per cell. The chosen protocol must independently pass fresh numeric validation. '
             'No fallback is allowed after validation failure. These numeric sets share task structures and are not confirmatory structural tests.', '']
    for name,decision in decisions.items():
        if decision is None:continue
        text += [f'### {name}', '',f"Decision: `{decision['status']}`. Queries: {decision['queries_completed']}/{decision['queries_planned']}.", '',
                 '| Protocol | Split | Family | Depth | Correct / n | Invalid |', '|---|---|---|---:|---:|---:|']
        text += [f"| {r['variant']} | {r['split']} | {r['family']} | {r['depth'] or '—'} | {r['correct']}/{r['n']} | {r['invalid']} |" for r in decision['cells']]
        text += ['']
    text += ['## Resources and deferred work','',
             'All model weights are existing local checkpoints. GPU work uses the shared four-hour cap; the second-family run needs '
             'a global reservation before its separate checkpoint ledger can be used. Stage ceilings do not grant additive budgets. '
             'Final outcomes remain sealed until a genuine registration and frozen forecasts exist. '
             'No language-model training or unlearning is included.', '',
             'The machine-readable plan is `configs/binding/phase2/program_plan.json`; current evidence and decisions are in '
             '`artifacts/binding/phase2/program_status.json`. Exact stage configurations and source/job pointers are retained.', '']
    target=Path(config.get('report','reports/binding/experiment_program.md'));target.parent.mkdir(parents=True,exist_ok=True);target.write_text('\n'.join(text))
    return {'report':str(target),'discovery_candidate':ready,'diagnostics_complete':done}
