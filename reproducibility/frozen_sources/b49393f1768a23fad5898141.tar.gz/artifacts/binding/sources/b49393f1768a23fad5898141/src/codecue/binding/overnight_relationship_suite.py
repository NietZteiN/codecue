"""Durable SLURM DAG and morning status for the overnight discovery suite."""
from __future__ import annotations

from datetime import datetime,timezone
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

from . import relationship_capture as base,overnight_relationship_capture as capture
from .datasets import digest

ROLE='discovery_overnight_relationship_suite_v1'
TRANSIENT={'TIMEOUT','PREEMPTED','NODE_FAIL','BOOT_FAIL'}
TERMINAL={'COMPLETED','FAILED','CANCELLED','TIMEOUT','PREEMPTED','NODE_FAIL','BOOT_FAIL','OUT_OF_MEMORY'}
SCRIPTS={'scripts/149_binding_overnight_relationship_capture.py','scripts/150_binding_overnight_relationship_readouts.py','scripts/151_binding_overnight_relationship_behavior.py'}


def _config(config):
    required={'evaluation_role','nodes','run_dir','report','morning_at','declared_plan','declared_plan_sha256'}
    if not isinstance(config,dict) or set(config)!=required or config.get('evaluation_role')!=ROLE:
        raise ValueError('exact overnight suite configuration required')
    for key in ('run_dir','report','declared_plan'):base._safe(config[key])
    if base._sha(config['declared_plan'])!=config['declared_plan_sha256']:raise ValueError('overnight suite plan changed')
    if datetime.fromisoformat(config['morning_at']).tzinfo is None:raise ValueError('explicit local morning offset required')
    names=[]
    for node in config['nodes']:
        required_node={'key','script','command','config','config_sha256','dependencies','partition','mem','cpus','time','time_min','phase','marker','marker_status','expected_cases'}
        if not isinstance(node,dict) or set(node)!=required_node or node['script'] not in SCRIPTS or node['phase'] not in ('gpu','cpu'):
            raise ValueError('exact typed overnight job node required')
        if node['key'] in names or set(node['dependencies'])-set(names):raise ValueError('unique topologically ordered suite nodes required')
        if base._sha(node['config'])!=node['config_sha256']:raise ValueError('overnight node configuration changed')
        base._safe(node['marker']);names.append(node['key'])
    if not names:raise ValueError('nonempty overnight job suite required')
    if Path(config['report']).resolve()==Path(config['declared_plan']).resolve():raise ValueError('suite report cannot replace its plan')


def _source(snapshot,config):
    from .snapshots import verify
    folder=Path(snapshot).resolve();m=verify(folder)
    result=dict(snapshot=str(folder),snapshot_id=m['snapshot_id'],source_sha256=m['code']['source_sha256'],frozen_manifest_sha256=base._sha(folder/'frozen_manifest.json'))
    base._verify_source(config,result);return result


def _submitter(source):
    spec=importlib.util.spec_from_file_location('overnight_frozen_submit',Path(source['snapshot'])/'scripts/slurm/submit.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def _save(config,state):
    capture._journal(Path(config['run_dir'])/'jobs_live_v1.json',state)


def _submit_node(config,state,node):
    module=_submitter(state['source'])
    deps=[state['attempts'][name][-1]['job_id'] for name in node['dependencies']
        if state['status'].get(name,{}).get('state')!='complete']
    argv=['/work/jvl210002/migration/envs/probe-cu129/bin/python',str(module.workspace_root(module.ROOT)/'scripts/91_binding_frozen_run.py'),
        state['source']['snapshot'],node['script'],node['command'],node['config']]
    attempts=state['attempts'][node['key']]
    minimum=node['time_min']
    if minimum and attempts and attempts[-1].get('state')=='TIMEOUT':
        minimum=attempts[-1].get('time_min') or minimum
        hours,minutes,seconds=map(int,minimum.split(':'));total=min((hours*3600+minutes*60+seconds)*2,7200)
        minimum=f'{total//3600:02d}:{total%3600//60:02d}:{total%60:02d}'
    job=module.submit('rel-night-'+node['key'],node['partition'],argv,
        dependency='afterok:'+':'.join(deps) if deps else None,mem=node['mem'],cpus=node['cpus'],time=node['time'],time_min=minimum)
    attempts.append(dict(job_id=job,state='SUBMITTED',progress_before=_progress(node),time_min=minimum,
        submitted_utc=datetime.now(timezone.utc).isoformat(),dependencies=deps))
    state['status'][node['key']]={'state':'submitted','job_id':job};_save(config,state)


def submit(config,snapshot,config_path):
    _config(config);source=_source(snapshot,config);folder=Path(config['run_dir']);folder.mkdir(parents=True,exist_ok=True)
    path=folder/'jobs_live_v1.json'
    if path.exists():raise ValueError('overnight suite already submitted; use watch/status, do not duplicate')
    if base._json(config_path)!=config:raise ValueError('suite configuration path differs')
    state=dict(evaluation_role=ROLE,config_hash=digest(config),source=source,config_path=str(config_path),
        attempts={n['key']:[] for n in config['nodes']},status={},controllers=[],created_utc=datetime.now(timezone.utc).isoformat())
    _save(config,state)
    for node in config['nodes']:
        if node['phase']=='gpu':_submit_node(config,state,node)
    _submit_controller(config,state)
    return status(config)


def _submit_controller(config,state,parent=None):
    module=_submitter(state['source'])
    argv=['/work/jvl210002/migration/envs/probe-cu129/bin/python',str(module.workspace_root(module.ROOT)/'scripts/91_binding_frozen_run.py'),
        state['source']['snapshot'],'scripts/152_binding_overnight_relationship_suite.py','watch',state['config_path']]
    job=module.submit('rel-night-controller','dev',argv,dependency='afterany:'+parent if parent else None,
        mem='4G',cpus=1,time='02:00:00')
    state['controllers'].append(job);_save(config,state)
    return job


def scheduler(ids,runner=None):
    runner=runner or subprocess.run
    if not ids:return {},[]
    if any(not str(value).isdigit() for value in ids):raise ValueError('numeric owned job IDs required')
    jobs={};errors=[]
    for command in [['sacct','-X','-n','-P','-j',','.join(ids),'--format=JobIDRaw,State%32,ExitCode,Reason%80,ElapsedRaw'],
                    ['squeue','-h','-j',','.join(ids),'-o','%i|%T|%r']]:
        try:r=runner(command,capture_output=True,text=True,timeout=20,check=False)
        except (OSError,subprocess.TimeoutExpired) as exc:errors.append(f'{command[0]}: {exc}');continue
        if r.returncode:errors.append(f'{command[0]}: {r.stderr.strip()}');continue
        for line in r.stdout.splitlines():
            fields=line.strip().split('|')
            if len(fields)<3 or fields[0] not in ids:continue
            entry=jobs.setdefault(fields[0],{});entry['state']=fields[1].split()[0].rstrip('+')
            if command[0]=='sacct':entry.update(exit_code=fields[2],reason=fields[3] if len(fields)>3 else '')
            else:entry['reason']=fields[2]
    return jobs,errors


def _marker(node):
    p=Path(node['marker'])
    if not p.exists():return False
    try:data=capture._json(p)
    except (ValueError,OSError):return False
    expected=node['marker_status']
    return (data.get('config_hash')==digest(base._json(node['config']))
        and (data.get('status')==expected if isinstance(expected,str) else data.get('complete') is expected))


def _progress(node):
    folder=Path(node['marker']).parent
    for name in ('progress.json','manifest.json'):
        try:data=capture._json(folder/name)
        except (OSError,ValueError):continue
        if 'fits' in data:return int(data['fits'])
        if 'chunks' in data:return sum(entry['rows'] for entry in data['chunks'])
    p=folder/'responses.jsonl'
    if p.exists():
        with p.open('rb') as stream:return sum(block.count(b'\n') for block in iter(lambda:stream.read(1024**2),b''))
    return 0


def reconcile(config,state,observed):
    """Pure transition decisions; only owned nodes can be retried/submitted."""
    actions=[];statuses={}
    for node in config['nodes']:
        key=node['key'];attempts=state['attempts'][key]
        parents=[statuses[name]['state'] for name in node['dependencies']]
        if not attempts:
            statuses[key]={'state':'blocked' if any(v in ('failed','blocked') for v in parents) else 'planned'}
            continue
        latest=attempts[-1];job=observed.get(latest['job_id'],{});raw=job.get('state','UNKNOWN')
        latest.update(job)
        if raw=='COMPLETED':
            statuses[key]={'state':'complete' if job.get('exit_code') in ('0:0','0') and _marker(node) else 'failed','job_id':latest['job_id']}
        elif raw in TRANSIENT:
            progress=_progress(node);latest['progress_after']=progress
            stalled=sum(a.get('progress_after',a.get('progress_before',0))<=a.get('progress_before',0) for a in attempts[-2:])
            retry=not(len(attempts)>=2 and stalled==2)
            statuses[key]={'state':'retry' if retry else 'failed','job_id':latest['job_id'],'reason':raw}
        elif raw=='CANCELLED' and job.get('reason')=='DependencyNeverSatisfied':
            statuses[key]={'state':'retry' if not any(v in ('failed','blocked') for v in parents) else 'blocked','job_id':latest['job_id']}
        elif raw in TERMINAL:statuses[key]={'state':'failed','job_id':latest['job_id'],'reason':job.get('reason',raw)}
        elif any(value in ('failed','blocked') for value in parents) and raw=='PENDING':
            statuses[key]={'state':'blocked','job_id':latest['job_id'],'reason':'required upstream stage failed'}
        else:statuses[key]={'state':raw.lower(),'job_id':latest['job_id'],'reason':job.get('reason')}
    gpu_terminal=all(statuses[n['key']]['state'] in ('complete','failed','blocked') for n in config['nodes'] if n['phase']=='gpu')
    for node in config['nodes']:
        item=statuses[node['key']]
        if item['state'] in ('planned','retry') and all(statuses[name]['state']=='complete' for name in node['dependencies']):
            if node['phase']=='gpu' or gpu_terminal:actions.append(node['key'])
    state['status']=statuses
    return actions


def _report(config,state,errors):
    values=[entry['state'] for entry in state['status'].values()]
    complete=bool(values) and all(value=='complete' for value in values)
    terminal=bool(values) and all(value in ('complete','failed','blocked') for value in values)
    science=[n for n in config['nodes'] if (n['script'].endswith('capture.py') and n['command']=='run') or n['script'].endswith('behavior.py')]
    observed_queries=0
    for node in science:
        try:journal=capture._json(Path(node['marker']).parent/'manifest.json')
        except (OSError,ValueError):continue
        observed_queries+=sum(a.get('prefill_cases_attempted',0) for a in journal.get('attempts',[]))
    result=dict(status='complete_exploratory' if complete else 'needs_attention' if terminal else 'running',
        evaluation_role=ROLE,config_hash=digest(config),recorded_utc=datetime.now(timezone.utc).isoformat(),
        stages=state['status'],attempts=state['attempts'],scheduler_errors=errors,all_terminal=terminal,
        source=state['source'],new_model_queries=0,generated_holdouts_opened=False,
        planned_scientific_case_prefills=sum(n['expected_cases'] for n in science),observed_scientific_prefill_attempts=observed_queries,
        scope='Controller metadata only. Scientific worker query counts remain in their own manifests.')
    folder=Path(config['run_dir']);capture._journal(folder/'status_review_v1.json',result)
    text=['# Overnight relationship suite','',f"Status: {result['status']}. Morning status time: {config['morning_at']}.",'',
        '| Stage | State | Latest job | Reason |','|---|---|---:|---|']
    for key,item in state['status'].items():text.append(f"| {key} | {item['state']} | {item.get('job_id','')} | {item.get('reason','')} |")
    text+=['','Stages use the frozen discovery plan. Failed scientific guards are reported rather than retried. Only resumable scheduler interruptions receive automatic retries; repeated failures with no committed progress stop retrying. Existing jobs outside this suite are never canceled.','']
    from .overnight_relationship_behavior import _replace_owned
    p=Path(config['report']);p.parent.mkdir(parents=True,exist_ok=True);_replace_owned(p,'\n'.join(text).encode())
    morning=datetime.fromisoformat(config['morning_at'])
    if (complete or datetime.now(timezone.utc)>=morning) and not (folder/'morning_review_v1.json').exists():base._put(folder/'morning_review_v1.json',result)
    return result


def status(config):
    _config(config);state=capture._json(Path(config['run_dir'])/'jobs_live_v1.json')
    ids=[a['job_id'] for attempts in state['attempts'].values() for a in attempts]
    observed,errors=scheduler(ids);reconcile(config,state,observed)
    return _report(config,state,errors)


def watch(config):
    from .confidence import _run_lock
    _config(config)
    with _run_lock(Path(config['run_dir'])):return _watch(config)


def _watch(config):
    _config(config);base._slurm();source=base._current_source(config)
    folder=Path(config['run_dir']);state=capture._json(folder/'jobs_live_v1.json')
    if state['source']!=source or state['config_hash']!=digest(config):raise ValueError('controller source/config identity differs')
    first=status(config)
    if first['all_terminal']:return first
    # Install successor before doing work, so a scheduler kill cannot orphan retry supervision.
    _submit_controller(config,state,parent=os.environ['SLURM_JOB_ID'])
    until=time.monotonic()+100*60;last_log=0
    while time.monotonic()<until:
        state=capture._json(folder/'jobs_live_v1.json')
        ids=[a['job_id'] for attempts in state['attempts'].values() for a in attempts]
        observed,errors=scheduler(ids);actions=reconcile(config,state,observed);_save(config,state)
        if not errors:
            for key in actions:_submit_node(config,state,next(n for n in config['nodes'] if n['key']==key))
        result=_report(config,state,errors)
        if time.monotonic()-last_log>600:
            from .experiment_log_scheduler import tick
            from .registry import ROOT
            from .snapshots import workspace_root
            tick(workspace_root(ROOT),force=True);last_log=time.monotonic()
        if result['all_terminal']:return result
        time.sleep(60)
    return _report(config,state,[])
