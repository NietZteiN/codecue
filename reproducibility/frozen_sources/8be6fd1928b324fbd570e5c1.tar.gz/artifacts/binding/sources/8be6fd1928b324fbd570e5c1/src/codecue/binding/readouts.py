"""Syntax-assisted distributed measurements; no semantic labels choose positions."""
from __future__ import annotations
import ast
import numpy as np


def latest_definition_sites(record,last_statement=None):
    statements=ast.parse(record['canonical_source']).body[:-1]
    limit=len(statements)-1 if last_statement is None else last_statement
    if not 0<=limit<len(statements):raise ValueError('readout prefix outside assignments')
    slots=record['variable_slots'];latest={}
    for index,statement in enumerate(statements[:limit+1]):
        if not isinstance(statement,ast.Assign) or not isinstance(statement.targets[0],ast.Name):
            raise ValueError('readout needs simple canonical assignments')
        name=statement.targets[0].id
        if name not in slots:raise ValueError('assignment not covered by canonical slots')
        latest[slots[name]]=index
    return {slot:f'statement:{index}' for slot,index in sorted(latest.items())}


def definition_pool(hidden,cache_row,record,layer_index,seed=17,last_statement=None):
    """Project latest-definition vectors to one hidden-width vector without labels.

    A slot-specific signed permutation makes ownership part of the measurement
    convention. The fixed projection is input-independent, untrained and lossy.
    It does not demonstrate that the model uses registers or these readout slots.
    """
    hidden=np.asarray(hidden)
    if hidden.ndim!=3 or hidden.shape[0]!=len(cache_row['sites']):
        raise ValueError('readout activation shape does not match cached sites')
    selected=latest_definition_sites(record,last_statement)
    width=hidden.shape[-1];result=np.zeros(width,dtype=np.float64)
    for slot,site in selected.items():
        if site not in cache_row['sites']:raise ValueError('readout definition site was not captured')
        rng=np.random.default_rng(seed+1009*slot)
        permutation=rng.permutation(width);signs=rng.integers(0,2,width)*2-1
        vector=hidden[cache_row['sites'].index(site),layer_index].astype(np.float64)
        result+=signs*vector[permutation]
    return result/np.sqrt(len(selected))


def definition_surface_source(record,last_statement=None):
    """Give the surface control the same slot/position assistance, without values."""
    selected=latest_definition_sites(record,last_statement)
    tree=ast.parse(record['source']);lines=[]
    limit=len(tree.body)-2 if last_statement is None else last_statement
    lines.extend(ast.unparse(stmt) for stmt in tree.body[:limit+1])
    for slot,site in selected.items():
        index=int(site.split(':')[1])
        lines.append(f'slot_{slot}_statement_{index}: '+ast.unparse(tree.body[index]))
    return '\n'.join(lines)
