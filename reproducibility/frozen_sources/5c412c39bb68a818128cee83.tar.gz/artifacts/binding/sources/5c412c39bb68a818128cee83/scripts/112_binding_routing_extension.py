#!/usr/bin/env python
"""Execute separately registered computed and dead-reference routing discovery."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('build', 'prepare', 'run', 'audit', 'review', 'audit-names'))
    parser.add_argument('config')
    args = parser.parse_args()
    from codecue.binding import routing_extension
    print(json.dumps(getattr(routing_extension, args.command.replace('-', '_'))(json.loads(Path(args.config).read_text())), indent=2))


if __name__ == '__main__':
    main()
