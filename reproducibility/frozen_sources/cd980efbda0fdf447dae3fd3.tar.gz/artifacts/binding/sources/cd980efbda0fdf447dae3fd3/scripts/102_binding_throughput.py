#!/usr/bin/env python
"""Profile installed GPU backends and validate the fastest completion pipeline."""
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('command', choices=('preflight', 'run', 'worker'))
parser.add_argument('config')
parser.add_argument('spec', nargs='?')
parser.add_argument('output', nargs='?')
args = parser.parse_args()
config = json.loads(Path(args.config).read_text())

if args.command == 'preflight':
    from codecue.binding.published_benchmarks import preflight
    result = preflight(config)
elif args.command == 'worker':
    from codecue.binding.throughput import worker
    result = worker(config, json.loads(Path(args.spec).read_text()), Path(args.output))
else:
    from codecue.binding.throughput import run
    result = run(config)
print(json.dumps(result, indent=2))
