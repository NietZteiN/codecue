#!/usr/bin/env python
"""Entry points for the explicitly authorized second research phase."""
import argparse
import json
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('command',choices=['audit','audit-boundary'])
parser.add_argument('config')
args=parser.parse_args()
config=json.loads(Path(args.config).read_text())
if args.command=='audit':
    from codecue.binding.checkpoint_audit import run
    result=run(config)
elif args.command=='audit-boundary':
    from codecue.binding.checkpoint_audit import audit_boundary
    result=audit_boundary(config)
print(json.dumps(result,indent=2))
