"""Train-only structural/algebraic readouts and independent value comparators.

This CPU controller consumes separately audited causal-prefix captures. Oracle
values, edges, source metadata and strata are targets/validation metadata only;
features are raw hidden coordinates or exact visible-prefix character ngrams.
"""
from __future__ import annotations

from collections import Counter
import io
import json
import os
from pathlib import Path
import time

import numpy as np

from .datasets import digest
from .discovery_readouts import group_weights
from .forecasting import _discovery_declaration, _discovery_response_path
from .published_benchmarks import immutable
from .registry import code_identity
from .representation_sensitivity import _json, _safe, _sha
from .weighted_ridge import fit as ridge_fit, from_parameters

ROLE = 'discovery_relationship_readouts_v1'
FIT_SITES = (3, 7, 8)
LAYERS = (8, 16, 24, 31)
SEEDS = (11, 29, 47)
FAMILIES = ('equal', 'less_than', 'sum_equals_third', 'difference_equals_third')
BOOTSTRAP = {'draws': 2000, 'seed': 117, 'minimum_valid_draws': 1900}
PRIMARY = {
    'algebraic': {'backend': 'hidden', 'site': 3, 'layer': 24, 'split': 'development',
        'metric': 'four_family_macro_balanced_accuracy', 'contrast': 'direct_minus_categorical_value_derived'},
    'structural': {'backend': 'hidden', 'site': 7, 'layer': 24, 'split': 'development',
        'metric': 'whole_parent_graph_accuracy', 'contrast': 'direct_minus_surface'},
}
MAX_RESULT_BYTES = 128*1024**2
COMPLETION_NAME = 'completion_manifest_v1.json'
LIMITATION = (
    'Prospective fixed readout recipe on an adaptive discovery bank, not final '
    'confirmation, natural causal use or mechanism C. Sites 3, 7 and 8 alone are '
    'fitted; other captured sites are reserved for later work. Raw 4096-dimensional '
    'hidden coordinates and matched 4096 character-ngram features have train-only '
    'float64 normalization and fixed alpha 100. Independent relation columns and '
    'value columns share a Gram factorization without output coupling. Primary '
    'algebraic comparisons use relations derived from four independent 32-class '
    'categorical value heads; rounded/clipped scalar-value derivation is secondary. '
    'Whole-pipeline parameter counts differ, so this is not an equal-total-capacity '
    'comparison. Numeric values, graph/stratum IDs and oracle relations never '
    'enter readout features. Binary ridge outputs are uncalibrated scores, with '
    'threshold 0.5. Undefined and constant tasks are retained and reported, not '
    'claimed as relationship learning. Primary eligibility uses only training '
    'group class support; all fixed eligible development cells must contain both '
    'classes. Components, not numeric/lexical relatives, are uncertainty units. '
    'Three seeds change component weights and coherent shuffle tasks, not '
    'independent experiments. Whole-program component derangements preserve '
    'unweighted target marginals, not necessarily weighted marginals. Conditional '
    'intervals resample nine development components without refitting or '
    'multiplicity adjustment. Successful relation decoding alone does not '
    'establish a dedicated relational representation or an identified algorithm.'
)


def protocol():
    return dict(fit_sites=list(FIT_SITES), layers=list(LAYERS), seeds=list(SEEDS), alpha=100.,
        feature_dimensions=4096, primary=PRIMARY, bootstrap=BOOTSTRAP,
        primary_train_class_group_minimum=12, binary_threshold=.5,
        scalar_value_derivation='numpy.rint then clip[-64,64], secondary',
        categorical_value_derivation='four independent 32-class score argmax heads, primary',
        group_weight_recipe='discovery_readouts.group_weights: exponential+1e-6; float32 mean normalization then float64 cast')


def _config(config):
    required = {'evaluation_role', 'capture_config', 'capture_config_sha256', 'capture_audit',
        'capture_audit_sha256', 'capture_registration', 'capture_registration_sha256', 'run_dir', 'report'}
    fixed = protocol(); optional = {'capture_summary', 'capture_summary_sha256'}
    if (not isinstance(config, dict) or config.get('evaluation_role') != ROLE
            or required-set(config) or set(config)-required-set(fixed)-optional):
        raise ValueError('explicit discovery relationship-readout configuration required')
    _discovery_declaration(config)
    if any(name in config and config[name] != value for name, value in fixed.items()):
        raise ValueError('fixed prospective relationship readout recipe differs')
    if ('capture_summary' in config) != ('capture_summary_sha256' in config):
        raise ValueError('optional capture summary path and pin must be supplied together')
    for key in ('capture_config', 'capture_audit', 'capture_registration', 'run_dir', 'report', *(['capture_summary'] if 'capture_summary' in config else [])):
        if not isinstance(config[key], str) or not config[key]: raise ValueError('explicit source/output path required')
        _discovery_response_path(config[key]); _safe(config[key])
    for key in ('capture_config_sha256', 'capture_audit_sha256', 'capture_registration_sha256', *(['capture_summary_sha256'] if 'capture_summary' in config else [])):
        value = config[key]
        if not isinstance(value, str) or len(value) != 64 or any(character not in '0123456789abcdef' for character in value):
            raise ValueError('explicit source metadata SHA256 pins required')
    return fixed


def _json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()


def _npz(path, arrays):
    stream = io.BytesIO(); np.savez(stream, **arrays); immutable(path, stream.getvalue())


def fit_complete_columns(x, y, mask, train, weights, case_ids, donor_indices):
    """One factorization for independent real/shuffled columns sharing row masks."""
    x = np.asarray(x, dtype=np.float64); y = np.asarray(y, dtype=np.float64)
    mask = np.asarray(mask); train = np.asarray(train); donor = np.asarray(donor_indices)
    n = len(x)
    if (x.ndim != 2 or y.ndim != 2 or len(y) != n or mask.shape != y.shape or mask.dtype != np.bool_
            or train.shape != (n,) or train.dtype != np.bool_ or donor.shape != (n,)
            or donor.dtype.kind not in 'iu' or set(donor.tolist()) != set(range(n))
            or not np.array_equal(train[donor], train) or not np.isfinite(x).all()
            or not np.isfinite(y[mask]).all() or len(case_ids) != n or len(set(case_ids)) != n):
        raise ValueError('complete finite discovery features/targets, IDs and split-preserving donor permutation required')
    active = np.flatnonzero(mask.all(axis=0))
    if not len(active) or np.any(mask.any(axis=0) != mask.all(axis=0)):
        raise ValueError('fixed fitted sites require complete or entirely undefined target columns')
    if train.sum() < 2: raise ValueError('training-only complete rows required')
    training_targets = np.concatenate((y[train][:, active], y[donor[train]][:, active]), axis=1)
    model = ridge_fit(x[train], training_targets, weights,
        train_ids=[case_ids[index] for index in np.flatnonzero(train)], split='train', alpha=100.)
    output = model.predict(x); width = len(active)
    real = np.full(y.shape, np.nan); shuffled = np.full(y.shape, np.nan)
    real[:, active], shuffled[:, active] = output[:, :width], output[:, width:]
    return model, active, real, shuffled


def family_macro_balanced_accuracy(correctness, truth, families):
    """Fixed-cell/family macro with class denominators recomputed on given rows."""
    correct = np.asarray(correctness, dtype=float); truth = np.asarray(truth)
    if (correct.ndim != 2 or truth.shape != correct.shape or len(families) != correct.shape[1]
            or not np.isfinite(correct).all() or np.any(correct < 0) or np.any(correct > 1)
            or not np.isin(truth, [0, 1]).all() or set(families) != set(FAMILIES)):
        raise ValueError('complete correctness/boolean truth for all four fixed relation families required')
    cells = []
    for column in range(correct.shape[1]):
        yes = truth[:, column] == 1; no = ~yes
        if not yes.any() or not no.any(): return None
        cells.append(.5*(float(correct[yes, column].mean())+float(correct[no, column].mean())))
    means = {family: float(np.mean([value for value, name in zip(cells, families) if name == family])) for family in FAMILIES}
    return dict(score=float(np.mean(list(means.values()))), families=means, cells=cells)


def algebraic_bootstrap(truth, method_correctness, groups, families):
    """Same nine-component draws/invalid-class rule for every original-label method."""
    truth = np.asarray(truth); groups = np.asarray(groups)
    if truth.ndim != 2 or groups.shape != (len(truth),) or len(set(groups.tolist())) != 9:
        raise ValueError('nine complete development components required')
    names = sorted(set(groups.tolist())); indices = [np.flatnonzero(groups == name) for name in names]
    methods = {name: np.asarray(value, dtype=float) for name, value in method_correctness.items()}
    points = {name: family_macro_balanced_accuracy(value, truth, families) for name, value in methods.items()}
    if any(value is None for value in points.values()):
        return dict(status='unqualified_primary_missing_development_class', methods=points,
            valid_draws=0, invalid_draws=BOOTSTRAP['draws'], comparisons={})
    rng = np.random.default_rng(BOOTSTRAP['seed']); differences = {name: [] for name in methods if name != 'direct'}
    invalid = 0
    for draw in rng.integers(0, 9, size=(BOOTSTRAP['draws'], 9)):
        chosen = np.concatenate([indices[index] for index in draw])
        scored = {name: family_macro_balanced_accuracy(value[chosen], truth[chosen], families) for name, value in methods.items()}
        if any(value is None for value in scored.values()): invalid += 1; continue
        for name in differences: differences[name].append(scored['direct']['score']-scored[name]['score'])
    valid = BOOTSTRAP['draws']-invalid; qualified = valid >= BOOTSTRAP['minimum_valid_draws']
    comparisons = {}
    for name, values in differences.items():
        comparisons['direct_minus_'+name] = dict(mean=points['direct']['score']-points[name]['score'],
            conditional_group_bootstrap_95=np.quantile(values, [.025, .975]).tolist() if qualified else None)
    return dict(status='qualified_conditional_interval' if qualified else 'unqualified_insufficient_valid_draws',
        methods=points, comparisons=comparisons, valid_draws=valid, invalid_draws=invalid,
        bootstrap=BOOTSTRAP, eligible_cells_fixed=True, same_invalid_draws_for_all_methods=True,
        seed_aggregation='Mean row correctness over three fixed fits before whole-group resampling; class denominators recomputed in every draw.',
        refits_per_draw=0, multiplicity_adjusted=False, groups=names)


def structural_bootstrap(method_correctness, groups):
    groups = np.asarray(groups); names = sorted(set(groups.tolist()))
    if len(names) != 9: raise ValueError('nine development components required for structural contrast')
    methods = {name: np.asarray(value, dtype=float) for name, value in method_correctness.items()}
    if any(value.shape != groups.shape or not np.isfinite(value).all() or np.any(value < 0) or np.any(value > 1) for value in methods.values()):
        raise ValueError('one finite whole-parent-graph correctness value per development row required')
    group_means = {name: np.array([value[groups == group].mean() for group in names]) for name, value in methods.items()}
    draws = np.random.default_rng(BOOTSTRAP['seed']).integers(0, 9, size=(BOOTSTRAP['draws'], 9))
    return dict(metric='whole_parent_graph_accuracy', methods={name: float(value.mean()) for name, value in group_means.items()},
        comparisons={'direct_minus_'+name: dict(mean=float((group_means['direct']-value).mean()),
            conditional_group_bootstrap_95=np.quantile((group_means['direct']-value)[draws].mean(axis=1), [.025, .975]).tolist())
            for name, value in group_means.items() if name != 'direct'},
        bootstrap=BOOTSTRAP, groups=names, refits_per_draw=0, multiplicity_adjusted=False,
        seed_aggregation='Mean row correctness over three fixed fits before nine whole-group draws.')
