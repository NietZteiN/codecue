"""Capacity-controlled shared linear state decoders with train-only preprocessing.

Primary estimator: ridge regression of four integer values, rounded to [-64,64].
Value recovery, obsolete-version recovery and sorted-multiset recovery use separate
four-output fits with identical capacity. Slot indexing is a measurement convention.
"""
from __future__ import annotations
import hashlib
import json
import time
from collections import Counter
from pathlib import Path
import numpy as np
from .datasets import read_jsonl, write_json
from .registry import guarded


def fit_ridge(x, y, alpha=1.0):
    # Fit normalization and every slot's mask using training rows only.
    mu, sd = x.mean(0), x.std(0).clip(1e-5)
    z = (x - mu) / sd
    width = y.shape[1]
    weights = np.zeros((x.shape[1], width), dtype=np.float64)
    intercept = np.zeros(width)
    for slot in range(width):
        mask = np.isfinite(y[:, slot])
        if not mask.any():
            continue
        a, b = z[mask], y[mask, slot]
        intercept[slot] = b.mean()
        b = b - intercept[slot]
        if len(a) < a.shape[1]:
            weights[:, slot] = a.T @ np.linalg.solve(a @ a.T + alpha * np.eye(len(a)), b)
        else:
            weights[:, slot] = np.linalg.solve(a.T @ a + alpha * np.eye(a.shape[1]), a.T @ b)
    return (mu, sd, weights, intercept)


def predict(model, x):
    mu, sd, weights, intercept = model
    return np.rint(((x - mu) / sd) @ weights + intercept).clip(-64, 64)


def metrics(pred, gold):
    if pred.shape != gold.shape:
        raise ValueError('probe output slots do not match evaluation labels')
    mask = np.isfinite(gold)
    whole = mask.all(1)
    return {'slot_exact_accuracy': float((pred[mask] == gold[mask]).mean()) if mask.any() else None,
            'whole_state_accuracy': float((pred[whole] == gold[whole]).all(1).mean()) if whole.any() else None,
            'mae': float(np.abs(pred[mask] - gold[mask]).mean()) if mask.any() else None,
            'defined_slot_labels': int(mask.sum()), 'complete_states': int(whole.sum())}


def surface_features(record, width=128):
    # Cheap token bag with assignment-distance and syntax features. No semantic oracle values.
    import re
    x = np.zeros(width + 4, dtype=np.float64)
    for token in re.findall(r'\w+|[^\s\w]', record['source']):
        index = int.from_bytes(hashlib.sha256(token.encode()).digest()[:4], 'little') % width
        x[index] += 1
    f = record['features']
    x[-4:] = [len(record['source']), f['arithmetic_operations'], f['statements'], record['updates']]
    return x


@guarded
def fit(config):
    from .registry import begin, finish
    out, manifest = begin(config, 'probes')
    started = time.monotonic()
    cache = Path(config['run_dir']) / 'activations'
    cache_manifest = json.loads((cache / 'manifest.json').read_text())
    if cache_manifest['status'] != 'complete':
        raise ValueError('activation extraction must be complete before probe fitting')
    if cache_manifest['identity']['code'] != manifest['identity']['code'] or cache_manifest['identity']['config'] != config:
        raise ValueError('activation cache identity mismatch')
    index = [r for r in read_jsonl(cache / 'index.jsonl') if r['control_kind'] == 'primary']
    if any(r['split'] == 'test' for r in index):
        raise ValueError('probe selection cannot open the sealed test')
    records = {r['id']: r for r in read_jsonl(config['dataset'])}
    results = []
    # Both sites share the complete final assignment state, but final source reveals query.
    for site in ('last_assignment', 'source_final'):
        for li, layer in enumerate(config['layers']):
            x, ys = [], {k: [] for k in ('current', 'previous', 'multiset')}
            for row in index:
                pi = len(row['sites']) - 2 if site == 'last_assignment' else len(row['sites']) - 1
                with np.load(cache / row['file']) as f:
                    x.append(f['hidden'][pi, li].astype(np.float64))
                point = row['checkpoints'][pi]
                for task in ys:
                    ys[task].append([np.nan if v is None else v for v in point[task]])
            x = np.array(x)
            surface = np.array([surface_features(records[r['id']]) for r in index])
            for task, labels in ys.items():
                y = np.array(labels, dtype=np.float64)
                width = y.shape[1]
                for train_condition in ('neutral', 'informative', 'misleading'):
                    train = np.array([i for i, r in enumerate(index) if r['split'] == 'train' and r['condition'] == train_condition])
                    if len(train) < 8:
                        raise ValueError('insufficient training rows for probe study; run extraction on full discovery data')
                    fitted = fit_ridge(x[train], y[train])
                    surface_fit = fit_ridge(surface[train], y[train])
                    majority = np.array([Counter(y[train, s][np.isfinite(y[train, s])]).most_common(1)[0][0]
                                         if np.isfinite(y[train, s]).any() else 0 for s in range(width)])
                    controls = []
                    for seed in (0, 1, 2):
                        # Base-keyed label tasks keep lexical relatives consistent; mapping is
                        # independent of semantic labels, structural split remains untouched.
                        draws = [int.from_bytes(hashlib.sha256(f'{seed}:{r["base_id"]}:{task}'.encode()).digest()[:4], 'little')
                                 for r in index]
                        random_y = y[train[np.array(draws) % len(train)]].copy()
                        for slot in range(width):
                            prior = y[train, slot][np.isfinite(y[train, slot])]
                            if len(prior):
                                missing = ~np.isfinite(random_y[:, slot]) & np.isfinite(y[:, slot])
                                random_y[missing, slot] = prior[np.array(draws)[missing] % len(prior)]
                        random_y[~np.isfinite(y)] = np.nan
                        controls.append((random_y, fit_ridge(x[train], random_y[train])))
                    for condition in ('neutral', 'informative', 'misleading'):
                        dev = np.array([i for i, r in enumerate(index) if r['split'] == 'development' and r['condition'] == condition])
                        if not len(dev):
                            continue
                        pred = predict(fitted, x[dev])
                        surface_pred = predict(surface_fit, surface[dev])
                        majority_pred = np.tile(majority, (len(dev), 1))
                        control_preds = [(ry, predict(m, x[dev])) for ry,m in controls]
                        if task == 'multiset':
                            pred = np.sort(pred, axis=1)
                            surface_pred = np.sort(surface_pred, axis=1)
                            majority_pred = np.sort(majority_pred, axis=1)
                            control_preds = [(ry, np.sort(p, axis=1)) for ry,p in control_preds]
                        result = {'site': site, 'layer': layer, 'task': task, 'train_condition': train_condition,
                                  'evaluation_condition': condition, 'evaluation_split': 'development',
                                  'train_n': len(train), 'development_n': len(dev),
                                  'parameters': width * (x.shape[1] + 1), 'surface_parameters': width * (surface.shape[1] + 1),
                                  'alpha': 1.0, 'linear': metrics(pred, y[dev]),
                                  'surface': metrics(surface_pred, y[dev]),
                                  'majority': metrics(majority_pred, y[dev]),
                                  'label_prior': [dict(Counter(y[train,s][np.isfinite(y[train,s])])) for s in range(width)],
                                  'randomized_label_controls': [metrics(p, ry[dev]) for ry,p in control_preds],
                                  'ids': [index[i]['id'] for i in dev], 'predictions': pred.tolist()}
                        # JSON object keys must be built-in scalar types.
                        result['label_prior'] = [{str(int(k)): int(v) for k, v in p.items()} for p in result['label_prior']]
                        results.append(result)
                    filename = f'{site}_L{layer}_{task}_{train_condition}.npz'
                    np.savez(out / filename, mu=fitted[0], sd=fitted[1], weights=fitted[2], intercept=fitted[3])
            print(f'probes {site} L{layer}', flush=True)
    write_json(out / 'development_curves.json', {'results': results, 'selection_status': 'none; full development curves only',
               'estimator': 'one linear output per canonical slot; ridge, train-only standardization, fixed alpha=1, integer rounding',
               'numeric_precision': 'float64 fitting from float16 activation cache',
               'limitations': 'decoding measures accessibility; no evidence of natural use or absence from failed decoding'})
    finish(out, manifest, time.monotonic() - started, result_count=len(results))
    return {'development_curves': str(out / 'development_curves.json'), 'results': len(results)}
