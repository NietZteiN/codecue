"""Conservative shared four-GPU-hour reservation ledger for this initial study."""
from __future__ import annotations
from contextlib import contextmanager
import fcntl
import json
from pathlib import Path
import uuid

CAP_SECONDS = 14400


@contextmanager
def locked(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.with_suffix('.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = json.loads(path.read_text()) if path.exists() else {'cap_seconds': CAP_SECONDS, 'used_seconds': 0., 'active': {}, 'completed': []}
        yield state
        temp = path.with_suffix('.tmp')
        temp.write_text(json.dumps(state, indent=2) + '\n')
        temp.replace(path)


def reserve(config, stage):
    if config['device'] != 'cuda' or stage not in ('behavior','activations','interventions','interface_diagnostics'):
        return None
    path = config.get('budget_ledger', 'artifacts/binding/gpu_budget.json')
    checkpoint = [config['model'], config['model_revision']]
    with locked(path) as state:
        if state.get('checkpoint', checkpoint) != checkpoint:
            raise ValueError('initial study budget permits one checkpoint')
        state['checkpoint'] = checkpoint
        remaining = state['cap_seconds'] - state['used_seconds'] - sum(r['reserved_seconds'] for r in state['active'].values())
        if remaining <= 0:
            raise ValueError('four-GPU-hour budget is spent or reserved; inspect the shared budget ledger')
        seconds = min(remaining, config['max_gpu_seconds'])
        lease = {'id': uuid.uuid4().hex, 'ledger': path, 'reserved_seconds': seconds,
                 'stage': stage, 'run_dir': config['run_dir']}
        state['active'][lease['id']] = lease
    return lease


def release(lease, seconds, status):
    if lease is None:
        return
    with locked(lease['ledger']) as state:
        if lease['id'] not in state['active']:
            raise ValueError('budget lease already closed')
        state['active'].pop(lease['id'])
        state['used_seconds'] += seconds
        state['completed'].append({**lease, 'actual_seconds': seconds, 'status': status})
