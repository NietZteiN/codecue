#!/usr/bin/env python
"""Render discovery evidence from existing artifacts; never runs a model or opens test outcomes."""
from __future__ import annotations
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from codecue.binding.analysis import interval
from codecue.binding.datasets import read_jsonl, write_json

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'artifacts/binding'
REPORT = ROOT / 'reports/binding/pilot_report.md'


def read(path):
    return json.loads(path.read_text())


def percent(value):
    return '—' if value is None else f'{100 * value:.1f}%'


def main():
    evidence = {'generated_utc': datetime.now(timezone.utc).isoformat(),
                'report_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'scope': 'discovery only; no heldout responses read', 'datasets': []}
    text = ['# Binding-study discovery pilot', '',
            'This report is generated from recorded artifacts. Results concern one cached CodeLlama checkpoint. '
            'No primary explanation among H1–H5 or confirmatory claim has been selected.', '',
            '## Behavioral feasibility', '']
    run = DATA / 'cpu_smoke_bf16_prefill_v2/behavior'
    if (run / 'summary.json').exists():
        summary, manifest = read(run / 'summary.json'), read(run / 'manifest.json')
        config = manifest['identity']['config']
        rows = read_jsonl(run / 'responses.jsonl')
        if any(r['split'] == 'test' for r in rows):
            raise ValueError('progress reports must not inspect heldout outcomes')
        evidence['behavior'] = {'manifest': str((run/'manifest.json').relative_to(ROOT)),
                                'identity_hash': manifest['identity_hash'], 'summary': summary}
        text += [f"Model `{config['model']}`, revision `{config['model_revision']}`; {config['dtype']}, "
                 f"{config['device']}, greedy `{config['protocol']}` with an assistant `Answer:` prefix. "
                 'The earlier unprefilled protocol produced explanations outside the strict integer parser; '
                 'its interrupted run is retained separately and excluded here.', '',
                 f"The completed balanced smoke has {len(rows)} responses across {summary['bases']} bases and "
                 f"{summary['independent_template_clusters']} parent-template clusters. "
                 f"Invalid outputs: {summary['invalid_count']}. All six naming renderings and both primary/arithmetic tasks are retained.", '',
                 '| Task | Responses | Exact accuracy | Cluster bootstrap 95% interval |',
                 '|---|---:|---:|---|']
        for kind, values in sorted(summary['by_control_kind'].items()):
            text.append(f"| {kind} | {values['n']} | {percent(values['accuracy']['estimate'])} | {values['accuracy']['ci95']} |")
        primary = [r for r in rows if r['control_kind'] == 'primary']
        text += ['', '| Primary naming | Responses | Correct |', '|---|---:|---:|']
        for condition in ('neutral', 'informative', 'misleading'):
            subset = [r for r in primary if r['condition'] == condition]
            text.append(f"| {condition} | {len(subset)} | {sum(r['correct'] for r in subset)} |")
        text += ['', 'Equal observed naming accuracies in this small sample do not establish equivalence. '
                 'The smoke contains only the lowest answer-magnitude bin; the full pilot covers three bins. '
                 'Arithmetic-control performance also leaves arithmetic and output selection as live explanations.', '',
                 '| Compatible error label (nonexclusive) | Responses | Independent bases |', '|---|---:|---:|---:|']
        for label, count in sorted(summary['counterfactual_consistent_error_counts_nonexclusive'].items()):
            bases = {r['base_id'] for r in rows if label in r['classification']['compatible_labels']}
            text.append(f'| {label} | {count} | {len(bases)} |')
        text += ['', f"Ambiguous errors: {summary['ambiguous_error_count']}. Compatible labels describe answers, "
                 'not identified internal causes. Lexical relatives are not independent replications.', '',
                 f"Behavior wall time: {manifest.get('wall_seconds_total', 0):.1f} s; "
                 f"CPU forward/generation time: {manifest.get('device_seconds', 0):.1f} s. "
                 'Raw responses, prompts, token IDs and exact identities are retained in the behavior directory.', '']
    text += ['## Representation measurements', '']
    base = DATA / 'cpu_representations_prefill_v2'
    probe_stage = 'probes_centered_v3' if (base/'probes_centered_v3/development_curves.json').exists() else 'probes'
    curves = base / probe_stage / 'development_curves.json'
    if curves.exists():
        cache_manifest = read(base/'activations/manifest.json')
        probe_manifest = read(base/probe_stage/'manifest.json')
        if cache_manifest['status'] != 'complete' or probe_manifest['status'] != 'complete':
            raise ValueError('do not report incomplete measurements as completed results')
        index = read_jsonl(base/'activations/index.jsonl')
        if any(r['split'] == 'test' for r in index):
            raise ValueError('probe report cannot read test activations')
        by_id = {r['id']:r for r in index}
        results = read(curves)['results']
        evidence['probes'] = {'manifest': str((base/probe_stage/'manifest.json').relative_to(ROOT)),
                              'identity_hash': probe_manifest['identity_hash'], 'development_intervals': []}
        text += [f"Extraction completed on {len(index)} primary train/development renderings "
                 f"({len({r['base_id'] for r in index})} bases), using {cache_manifest['artifact_bytes']:,} retained bytes. "
                 'Probes use fixed-alpha ridge, train-only normalization, integer rounding and separate current/previous/multiset fits. '
                 'All supplied sites and layers are reported; none is selected as a primary mechanism.', '',
                 '| Site | Block | Task | Hidden slot accuracy | 95% cluster interval | Surface | Mode | Random-label mean |',
                 '|---|---:|---|---:|---|---:|---:|---:|']
        for row in results:
            if row['train_condition'] != 'neutral' or row['evaluation_condition'] != 'neutral':
                continue
            values, clusters = [], []
            for identifier, prediction in zip(row['ids'], row['predictions']):
                example = by_id[identifier]
                pi = -2 if row['site'] == 'last_assignment' else -1
                gold = example['checkpoints'][pi][row['task']]
                for observed, target in zip(prediction, gold):
                    if target is not None:
                        values.append(observed == target)
                        clusters.append(example['cluster_id'])
            ci = interval(values, clusters)
            evidence['probes']['development_intervals'].append({
                **{k:row[k] for k in ('site','layer','task')}, **ci})
            random_mean = np.mean([r['slot_exact_accuracy'] for r in row['randomized_label_controls']])
            text.append(f"| {row['site']} | {row['layer']} | {row['task']} | "
                        f"{percent(row['linear']['slot_exact_accuracy'])} | {ci['ci95']} | "
                        f"{percent(row['surface']['slot_exact_accuracy'])} | {percent(row['majority']['slot_exact_accuracy'])} | "
                        f"{percent(random_mean)} |")
        surface_note = ('The surface baseline uses the same visible source prefix as each hidden site. '
                        if probe_stage == 'probes_centered_v3' else
                        'The surface baseline reads the full source even at the last-assignment site; this gives that baseline the later query. ')
        text += ['', 'The table uses neutral training and neutral development. The complete JSON contains every within-condition fit '
                 'and cross-condition transfer, MAE, whole-state scores, capacity and label priors. '
                 'Intervals resample parent-template clusters and are descriptive, without correction for selecting among sites/layers. '
                 'Random-label accuracy concerns a different target task and is not a paired improvement estimate. '
                 + surface_note + 'These measurements establish neither natural causal use nor information absence when decoding fails.', '']
    else:
        text += ['Activation extraction or probe fitting is pending; no recovery result is claimed.', '']
    text += ['## Causal assay', '']
    assay = DATA/'cpu_value_assay_prefill_v2/interventions'
    if (assay/'summary.json').exists() and read(assay/'manifest.json')['status'] == 'complete':
        result = read(assay/'summary.json')
        evidence['value_assay'] = result
        text += ['This development calibration uses one predeclared block, computed donors and accumulator programs. '
                 'Recipients were selected by stable ID within factorial cells rather than by successful patching. '
                 'Late quantity queries can trigger reconstruction; full-residual transfer does not isolate a natural pathway.', '',
                 '| Control | Recipients | Counterfactual output | Dependent quantities | Independent quantities |',
                 '|---|---:|---:|---:|---:|']
        for control in result['controls']:
            text.append(f"| {control['control']} | {control['n']} | "
                        f"{percent(control['counterfactual_accuracy']['estimate'])} | "
                        f"{percent(control.get('dependent_quantity_accuracy',{}).get('estimate'))} | "
                        f"{percent(control.get('independent_quantity_accuracy',{}).get('estimate'))} |")
        text += ['', 'Complete likelihood margins, bootstrap intervals, baseline-correct counts and raw responses are retained. '
                 'Ownership-matched intervention and path specificity are not established by this calibration.', '']
    else:
        text += ['The development value-transfer assay is queued or running. No causal result is claimed.', '']
    text += ['## Reserved structural data', '',
             '| Cohort | Bases | Renderings | Independent Python checks | Dataset SHA-256 |',
             '|---|---:|---:|---:|---|']
    for axis in ('depth','distance','competition','combined'):
        path = DATA/f'extrapolation_{axis}_full.manifest.json'
        if not path.exists():
            continue
        manifest = read(path)
        validation = read(path.with_name(path.name.replace('.manifest.', '.validation.')))
        if validation['status'] != 'passed':
            raise ValueError('reserved dataset did not pass validation')
        evidence['datasets'].append({'cohort':axis,'manifest':str(path.relative_to(ROOT)),
                                    'sha256':manifest['sha256'],'validation':validation})
        text.append(f"| {axis} | {manifest['base_instances']} | {manifest['rows']} | "
                    f"{validation['independent_python_programs']} | `{manifest['sha256']}` |")
    text += ['', 'All these cohorts are test-only. Generator version 6 checks actual primary and control skeletons against '
             'the discovery dataset, verifies independent Python traces and downstream counterfactual states, and rejects '
             'cross-base duplicate numeric ASTs. Their model outcomes remain unopened. Increased competition uses six variables; '
             'distance padding adds arithmetic identities and is not a pure timing manipulation. The smaller structural smoke '
             'fixtures are separate from the full cohorts. No new-family extrapolation has been implemented yet.', '',
             '## Decision and remaining work', '',
             'Continue discovery before selecting H1–H5. Inspect the complete probe controls and value-assay negative controls, '
             'then decide whether an ownership/path-specific follow-up is justified. The naming smoke alone provides no positive '
             'binding-interference finding. A supported hypothesis, frozen predictor fitting and unfamiliar-program forecasts '
             'are still required before opening final model outcomes. No optional training, second checkpoint or empirical '
             'paper abstract has been started.', '',
             'Queued-job identities and immutable source pointers are recorded in the adjacent handoff and artifact manifests. '
             'GPU experiment time remains subject to the shared four-hour ledger; CPU results are kept separate from any GPU replication.', '']
    REPORT.write_text('\n'.join(text))
    write_json(DATA/'phase2_evidence.json', evidence)
    print(json.dumps({'report':str(REPORT), 'evidence':str(DATA/'phase2_evidence.json')},indent=2))


if __name__ == '__main__':
    main()
