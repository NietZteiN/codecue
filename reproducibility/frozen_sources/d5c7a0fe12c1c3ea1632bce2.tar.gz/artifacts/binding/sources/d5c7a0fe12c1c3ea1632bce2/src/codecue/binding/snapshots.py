"""Content-addressed source snapshots for long queued or running experiments."""
from __future__ import annotations
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from .datasets import digest, write_json

SCRIPT_NAMES = ('87_binding_preflight.py', '88_binding_pipeline.py', '89_binding_design_audit.py',
                '90_binding_vocab_check.py', '91_binding_frozen_run.py', '92_binding_progress_report.py',
                '93_binding_calibration_pipeline.py','94_binding_probe_regularization.py','95_binding_difficulty_ladder.py',
                '96_binding_program.py','97_binding_published_benchmarks.py','98_binding_published_review.py',
                '99_binding_serialization.py','100_binding_serialization_dispatch.py',
                '101_binding_experiment_status.py','102_binding_throughput.py',
                '103_binding_throughput_audit.py','104_binding_checkpoint_suite.py','105_binding_competition.py')


def source_files(root):
    root = Path(root)
    files = list((root / 'src/codecue').rglob('*.py'))
    files += [root / 'scripts' / name for name in SCRIPT_NAMES]
    files += [root / 'scripts/env.sh', root / 'scripts/slurm/submit.py', root / 'scripts/slurm/stamp.py']
    return sorted(files)


def hashes(root):
    root = Path(root)
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files(root)}


def verify(root):
    root = Path(root)
    manifest = json.loads((root / 'frozen_manifest.json').read_text())
    # A newer working tree may capture more entrypoints than an older snapshot.
    # Verify what the isolated snapshot actually contains, not today's catalog.
    captured = list((root/'src/codecue').rglob('*.py')) + list((root/'scripts').rglob('*.py'))
    captured += [root/'scripts/env.sh']
    try:
        actual = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(captured)}
    except FileNotFoundError as exc:
        raise ValueError('frozen source checksum mismatch') from exc
    if actual != manifest['code']['source_files'] or digest(actual) != manifest['code']['source_sha256']:
        raise ValueError('frozen source checksum mismatch')
    for name, expected in manifest['config_files'].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f'frozen configuration changed: {name}')
    return manifest


def workspace_root(source_root):
    """Separate immutable experiment code from writable workspace artifacts."""
    source_root=Path(source_root).resolve()
    if (source_root/'frozen_manifest.json').exists():
        return Path(verify(source_root)['workspace_root']).resolve()
    return source_root


def freeze(output=None):
    from .registry import ROOT, code_identity
    identity = code_identity()
    configs = sorted((ROOT / 'configs').rglob('*.json')) + sorted((ROOT / 'configs').glob('*.yaml'))
    config_hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in configs}
    snapshot_id = digest({'code': identity, 'configs': config_hashes})[:24]
    target = Path(output) if output else ROOT / 'artifacts/binding/sources' / snapshot_id
    if target.exists():
        previous = verify(target)
        if previous['code'] != identity or previous['config_files'] != config_hashes:
            raise ValueError('snapshot directory belongs to another source/config identity')
        return {'snapshot': str(target.resolve()), 'snapshot_id': snapshot_id, 'code': identity['source_sha256']}
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + '.staging')
    if staging.exists():
        raise ValueError('unfinished snapshot staging directory; inspect before retrying')
    for path in source_files(ROOT) + configs:
        relative = path.relative_to(ROOT)
        (staging / relative).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, staging / relative)
    write_json(staging / 'frozen_manifest.json', {
        'snapshot_id': snapshot_id, 'code': identity, 'config_files': config_hashes,
        'workspace_root': str(ROOT.resolve()), 'created_utc': datetime.now(timezone.utc).isoformat(),
        'purpose': 'immutable experiment source and configurations; model weights/data remain content-verified upstream artifacts'})
    verify(staging)
    staging.rename(target)
    return {'snapshot': str(target.resolve()), 'snapshot_id': snapshot_id, 'code': identity['source_sha256']}
