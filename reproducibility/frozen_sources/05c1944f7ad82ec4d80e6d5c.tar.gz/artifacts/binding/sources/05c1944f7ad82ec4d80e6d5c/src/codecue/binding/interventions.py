"""Development-only full-residual value-transfer assay and negative controls.

This is an assay, not automatic binding localization. Sites must be supplied in
config before execution; no automatic sweep or choice based on final-test labels.
"""
from __future__ import annotations
from contextlib import contextmanager
import copy
import json
import time
import numpy as np
from .datasets import read_jsonl, write_json
from .interpreter import execute, substituted_source
from .behavior import parse_answer
from .registry import guarded


@contextmanager
def residual_patch(block, position, vector):
    """Patch prefill only during cached generation; always remove the hook."""
    def hook(module, args, output):
        h = output[0] if isinstance(output, tuple) else output
        if h.shape[1] > position:
            h = h.clone()
            h[:, position, :] = vector.to(device=h.device, dtype=h.dtype)
            return (h, *output[1:]) if isinstance(output, tuple) else h
        return output
    handle = block.register_forward_hook(hook)
    try:
        yield
    finally:
        handle.remove()


def changed_record(recipient, changes):
    """Changes refer to canonical assignments; spans rebuilt after AST rendering."""
    from .programs import rename
    source = recipient['canonical_source']
    for definition, replacement in changes.items():
        source = substituted_source(source, definition, replacement)
    truth = execute(source)
    row = copy.deepcopy(recipient)
    row.update(truth)
    row['canonical_source'] = source
    row['source'] = rename(source, row['rename_map'])
    offset = 0
    row['statement_spans'] = []
    for i, line in enumerate(row['source'].splitlines()):
        row['statement_spans'].append({'statement': i, 'start': offset, 'end': offset + len(line)})
        offset += len(line) + 1
    return row


@guarded
def run(config):
    import torch
    from codecue.patching import decoder_layers
    from .model_adapter import load, prompt_for, layout, score_answers
    from .registry import begin, finish
    from .analysis import interval
    assay = config.get('intervention')
    if not assay or assay.get('split') != 'development' or len(assay.get('layers', [])) != 1:
        raise ValueError('supply one predeclared development intervention layer in config')
    out, manifest = begin(config, 'interventions')
    started = time.monotonic()
    tokenizer, model = load(config)
    blocks = decoder_layers(model)
    layer = assay['layers'][0]
    if not 0 <= layer < len(blocks):
        raise ValueError('invalid intervention layer')
    rows = [r for r in read_jsonl(config['dataset']) if r['split'] == 'development'
            and r['condition'] == 'neutral' and r['lexical_realization'] == 0 and r['control_kind'] == 'primary']
    by_cell, recipients = {}, []
    for r in rows:
        by_cell.setdefault((r['family'], r['load'], r['updates']), []).append(r)
    for cell, group in sorted(by_cell.items()):
        recipients.extend(sorted(group, key=lambda r: r['id'])[:assay.get('per_cell_limit', 1)])
    rng = np.random.default_rng(config['seed'])
    output = out / 'assays.jsonl'
    if output.exists():
        raise ValueError('intervention assay is immutable; use a new run directory to repeat')

    def hidden(row, site):
        prompt = prompt_for(tokenizer, row)
        aligned = layout(tokenizer, row, prompt)
        pos = aligned['positions'][site]
        captured = []
        def hook(module, args, result):
            h = result[0] if isinstance(result, tuple) else result
            captured.append(h[0, pos].detach().clone())
        handle = blocks[layer].register_forward_hook(hook)
        try:
            with torch.inference_mode():
                model(input_ids=torch.tensor([aligned['input_ids']], device=model.device), use_cache=False)
        finally:
            handle.remove()
        return captured[0], aligned, prompt

    for recipient in recipients:
        if time.monotonic() - started > manifest['budget_seconds_available']:
            break
        last = recipient['execution_trace'][-1]
        target, wrong = last['versions']['v1'], last['versions']['v0']
        source_value = last['values']['v1'] + 2
        if abs(source_value) > 64:
            continue
        donor = changed_record(recipient, {target: source_value})
        expected = donor['expected_answer']
        site = f"statement:{len(recipient['execution_trace']) - 1}"
        rh, aligned, prompt = hidden(recipient, site)
        dh, _, _ = hidden(donor, site)
        wrong_donor = changed_record(recipient, {wrong: last['values']['v0'] + 2})
        wh, _, _ = hidden(wrong_donor, site)
        history = [p for p in recipient['execution_trace'] if p['definition'].startswith('v1@')]
        older = history[-2]['value'] if len(history) > 1 else last['values']['v1']
        old_donor = changed_record(recipient, {target: older})
        oh, _, _ = hidden(old_donor, site)
        same_answer = changed_record(recipient, {target: source_value, wrong: last['values']['v0'] + 4})
        if same_answer['expected_answer'] != recipient['expected_answer']:
            raise ValueError('same-answer control failed semantic check')
        sh, _, _ = hidden(same_answer, site)
        group = by_cell[(recipient['family'], recipient['load'], recipient['updates'])]
        shuffle = next((r for r in group if r['base_id'] != recipient['base_id']), None)
        if shuffle is None:
            raise ValueError('need at least two development bases per cell for donor control')
        random_h, _, _ = hidden(shuffle, site)
        delta = dh - rh
        permutation = torch.tensor(rng.permutation(len(delta)), device=delta.device)
        controls = [('no_op', None), ('self_patch', rh), ('value_donor', dh), ('wrong_variable', wh),
                    ('wrong_version', oh), ('same_answer_different_state', sh), ('shuffled_donor', random_h),
                    ('matched_norm_random_direction', rh + delta[permutation])]
        candidates = [recipient['expected_answer'], expected, wrong_donor['expected_answer'], old_donor['expected_answer']]
        ids = torch.tensor([aligned['input_ids']], device=model.device)
        baseline_prediction = None
        for label, vector in controls:
            ctx = residual_patch(blocks[layer], aligned['positions'][site], vector) if vector is not None else null_context()
            with ctx, torch.inference_mode():
                generated = model.generate(input_ids=ids, attention_mask=torch.ones_like(ids), max_new_tokens=config['max_new_tokens'],
                                           do_sample=False, pad_token_id=tokenizer.pad_token_id, eos_token_id=tokenizer.eos_token_id)
                raw = tokenizer.decode(generated[0, ids.shape[1]:], skip_special_tokens=True)
                scores = score_answers(tokenizer, model, prompt, candidates)
            pred = parse_answer(raw)
            if label == 'no_op':
                baseline_prediction = pred
            item = {'id': recipient['id'], 'template_id': recipient['template_id'], 'cluster_id': recipient['cluster_id'], 'base_id': recipient['base_id'],
                    'layer': layer, 'site': site, 'control': label, 'raw_response': raw, 'prediction': pred,
                    'recipient_answer': recipient['expected_answer'], 'counterfactual_answer': expected,
                    'exact_counterfactual': pred == expected, 'baseline_correct': baseline_prediction == recipient['expected_answer'],
                    'baseline_prediction': baseline_prediction,
                    'expected_downstream_state': donor['execution_trace'][-1]['values'],
                    'observed_downstream_state': None,
                    'state_specificity_status': 'not measured; final output alone cannot establish binding specificity',
                    'scores': scores, 'patch_delta_norm': float(torch.linalg.vector_norm(vector - rh)) if vector is not None else 0.0,
                    'target_definition': target, 'donor_source': donor['source'],
                    'assay_type': 'value transfer, not binding repair'}
            with output.open('a') as f:
                f.write(json.dumps(item) + '\n')
        # Reciprocal natural donor direction uses precisely the same site correspondence.
        dh2, donor_layout, donor_prompt = hidden(donor, site)
        donor_ids = torch.tensor([donor_layout['input_ids']], device=model.device)
        with residual_patch(blocks[layer], donor_layout['positions'][site], rh), torch.inference_mode():
            generated = model.generate(input_ids=donor_ids, attention_mask=torch.ones_like(donor_ids),
                max_new_tokens=config['max_new_tokens'], do_sample=False, pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id)
        raw = tokenizer.decode(generated[0, donor_ids.shape[1]:], skip_special_tokens=True)
        with output.open('a') as f:
            f.write(json.dumps({'id': recipient['id'], 'base_id': recipient['base_id'], 'template_id': recipient['template_id'], 'cluster_id': recipient['cluster_id'],
                'control': 'reciprocal_value_donor', 'raw_response': raw, 'prediction': parse_answer(raw),
                'exact_counterfactual': parse_answer(raw) == recipient['expected_answer'],
                'recipient_answer': donor['expected_answer'], 'counterfactual_answer': recipient['expected_answer'],
                'layer': layer, 'site': site}) + '\n')
        print(f"assay {recipient['base_id']}", flush=True)
    actual = read_jsonl(output)
    def likelihood_margin(row):
        scores = {s['answer']: s['log_likelihood_sum'] for s in row['scores']['scores']}
        return scores[row['counterfactual_answer']] - scores[row['recipient_answer']]
    baselines = {r['id']: r for r in actual if r['control'] == 'no_op'}
    summary = []
    for control in sorted({r['control'] for r in actual}):
        subset = [r for r in actual if r['control'] == control]
        entry = {'control': control, 'n': len(subset),
                 'counterfactual_accuracy': interval([r['exact_counterfactual'] for r in subset], [r['cluster_id'] for r in subset])}
        scored = [r for r in subset if 'scores' in r]
        if scored:
            entry['counterfactual_log_likelihood_margin_change'] = interval(
                [likelihood_margin(r) - likelihood_margin(baselines[r['id']]) for r in scored],
                [r['cluster_id'] for r in scored])
            entry['baseline_correct_n'] = sum(r['baseline_correct'] for r in scored)
            entry['induced_counterfactual_on_baseline_correct_n'] = sum(r['baseline_correct'] and r['exact_counterfactual'] for r in scored)
        summary.append(entry)
    write_json(out / 'summary.json', {'controls': summary, 'interpretation': 'development value-transfer assay only; specificity unestablished'})
    finish(out, manifest, time.monotonic() - started, samples_completed=len(actual))
    return {'assays': str(output), 'summary': str(out / 'summary.json')}


@contextmanager
def null_context():
    yield
