#!/usr/bin/env python
"""Run, inspect or replay frozen varied-schedule discovery readouts."""
import argparse
import json
from codecue.binding import schedule_readouts as study
from codecue.binding import relationship_capture as bounded


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('preflight', 'run', 'audit', 'completed_result'))
    parser.add_argument('config')
    args = parser.parse_args()
    path = bounded._safe(args.config)
    if path.suffix != '.json' or path.stat().st_size > 16*1024:
        raise ValueError('bounded discovery configuration required')
    value = getattr(study, args.command)(json.loads(path.read_text()))
    print(json.dumps({key: value[key] for key in
        ('status', 'evaluation_role', 'cases', 'fit_banks', 'factorizations',
         'parameter_replay_rows', 'new_model_queries') if key in value}, sort_keys=True, indent=2))


if __name__ == '__main__': main()
